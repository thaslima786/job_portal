<?php

session_start();

if (!isset($_SESSION['id'])) {
    header("Location: ../login.php");
}

?>

<!DOCTYPE html>
<html>

<head>
    <title>Admin Dashboard</title>
</head>

<body>

    <h1>
        Admin Dashboard
    </h1>

    <h3>
        Welcome
        <?php echo $_SESSION['name']; ?>
    </h3>

    <a href="../logout.php">
        Logout
    </a>

</body>

</html>