<?php

include("config/db.php");

echo "Database: ";

$result = mysqli_query($conn, "SELECT DATABASE()");
$row = mysqli_fetch_row($result);

echo $row[0] . "<br><br>";

$result = mysqli_query($conn, "SHOW TABLES");

while ($row = mysqli_fetch_row($result)) {
    echo $row[0] . "<br>";
}

?>