<!DOCTYPE html>
<html>

<head>
    <title>Job Portal</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>

    <nav>
        <h2>Job Portal</h2>

        <div>
            <a href="login.php">Login</a>
            <a href="register.php">Register</a>
        </div>

    </nav>

    <section class="hero">

        <h1>Find Your Dream Job</h1>

        <p>
            Apply to top companies and start your career.
        </p>

        <a href="register.php" class="btn">
            Get Started
        </a>

    </section>

</body>

</html>