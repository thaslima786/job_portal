<?php
include("config/db.php");

$message = "";

if (isset($_POST['register'])) {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Check email already exists
    $check = mysqli_query(
        $conn,
        "SELECT * FROM users WHERE email='$email'"
    );

    if (!$check) {
        die("SQL Error: " . mysqli_error($conn));
    }

    if (mysqli_num_rows($check) > 0) {
        $message = "Email already exists!";
    } else {
        $insert = mysqli_query(
            $conn,
            "INSERT INTO users(name,email,password)
             VALUES('$name','$email','$password')"
        );

        if ($insert) {
            $message = "Registration Successful!";
        } else {
            $message = "Insert Error: " . mysqli_error($conn);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Job Portal - Register</title>

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap"
        rel="stylesheet">

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background: linear-gradient(135deg, #4f46e5, #7c3aed);
        }

        .container {
            width: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .card {
            width: 420px;
            background: #fff;
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, .2);
        }

        .logo {
            text-align: center;
            font-size: 45px;
            margin-bottom: 10px;
        }

        h2 {
            text-align: center;
            color: #111827;
            margin-bottom: 10px;
        }

        .subtitle {
            text-align: center;
            color: #6b7280;
            margin-bottom: 25px;
        }

        .message {
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 15px;
            text-align: center;
            font-size: 14px;
        }

        .success {
            background: #dcfce7;
            color: #166534;
        }

        .error {
            background: #fee2e2;
            color: #991b1b;
        }

        input {
            width: 100%;
            padding: 14px;
            margin-bottom: 15px;
            border: 1px solid #d1d5db;
            border-radius: 10px;
            font-size: 15px;
        }

        input:focus {
            outline: none;
            border-color: #4f46e5;
            box-shadow: 0 0 10px rgba(79, 70, 229, .3);
        }

        button {
            width: 100%;
            padding: 14px;
            border: none;
            border-radius: 10px;
            background: linear-gradient(135deg, #4f46e5, #7c3aed);
            color: white;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: .3s;
        }

        button:hover {
            transform: translateY(-2px);
        }

        .login-link {
            text-align: center;
            margin-top: 20px;
        }

        .login-link a {
            color: #4f46e5;
            text-decoration: none;
            font-weight: 600;
        }

        .login-link a:hover {
            text-decoration: underline;
        }
    </style>

</head>

<body>

    <div class="container">

        <div class="card">

            <div class="logo">💼</div>

            <h2>Create Account</h2>

            <p class="subtitle">
                Join Our Job Portal Community
            </p>

            <?php if (!empty($message)) { ?>

                <div class="message <?php echo ($message == 'Registration Successful!') ? 'success' : 'error'; ?>">
                    <?php echo $message; ?>
                </div>

            <?php } ?>

            <form method="POST">

                <input type="text" name="name" placeholder="Full Name" required>

                <input type="email" name="email" placeholder="Email Address" required>

                <input type="password" name="password" placeholder="Password" required>

                <button type="submit" name="register">
                    Create Account
                </button>

            </form>

            <div class="login-link">
                Already have an account?
                <a href="login.php">Login</a>
            </div>

        </div>

    </div>

</body>

</html>