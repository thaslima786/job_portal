<?php

include("config/db.php");

echo "<h2>Database Information</h2>";

$result = mysqli_query($conn, "SELECT DATABASE()");
$row = mysqli_fetch_row($result);

echo "Database: " . $row[0] . "<br><br>";

$result = mysqli_query($conn, "SHOW TABLES");

$count = 0;

while ($table = mysqli_fetch_row($result)) {
    echo $table[0] . "<br>";
    $count++;
}

echo "<br>Total Tables: " . $count;

?>