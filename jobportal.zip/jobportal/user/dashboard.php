```php
<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Dashboard</title>

    <style>
        body {
            font-family: Poppins, sans-serif;
            background: #f5f7fb;
            margin: 0;
        }

        .header {
            background: #4f46e5;
            color: white;
            padding: 20px;
            text-align: center;
        }

        .container {
            max-width: 1000px;
            margin: 40px auto;
            text-align: center;
        }

        .card {
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, .1);
        }

        a {
            display: inline-block;
            margin-top: 20px;
            background: #ef4444;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 8px;
        }
    </style>

</head>

<body>

    <div class="header">
        <h1>Job Portal Dashboard</h1>
    </div>

    <div class="container">

        <div class="card">

            <h2>Welcome,
                <?php echo $_SESSION['name']; ?> 🎉
            </h2>

            <p>Login Successful</p>

            <a href="logout.php">Logout</a>

        </div>

    </div>

</body>

</html>